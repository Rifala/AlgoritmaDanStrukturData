import java.util.Scanner;

public class z {
    private static void bio() {
        String NIM;
        String Nama;
        String Kelas;
        String Tugas;

        NIM = "21090043";
        Nama = "Balkis Arifatul Fadia";
        Kelas = "1A";
        Tugas = "Bilangan Prima menggunakan method tanpa parameter";

        System.out.println("NIM : " + NIM);
        System.out.println("Nama : " + Nama);
        System.out.println("Kelas : " + Kelas);
        System.out.println("Tugas : " + Tugas);
    }

    private static void BilanganPrima() {
        Scanner input;
        input = new Scanner(System.in);
        System.out.print("Masukkan Angka : ");
        int angka = input.nextInt();


        int cek;
        cek = 0;

        for (int i = 2; i<=angka; i++){
            if (angka % i == 0){
                cek++;
            }
        }
            if (cek == 1){
                System.out.println(angka + " adalah bilangan prima");
            }else{
                 System.out.println(angka + " bukan bilangan prima");
            }
    }

    public static void main(String[] args) {
        bio();
        BilanganPrima();
    }
}
