import java.util.Scanner;

public class PrimeMethodNonParameter {
    private static void bio(){
    String NIM;
    String Nama;
    String Kelas;
    String Tugas;

    NIM = "21090043";
    Nama = "Balkis Arifatul Fadia";
    Kelas = "1A";
    Tugas = "Bilangan Prima menggunakan method tanpa parameter";

        System.out.println("NIM : " + NIM);
        System.out.println("Nama : " + Nama);
        System.out.println("Kelas : " + Kelas);
        System.out.println("Tugas : " + Tugas);
    }

    private static void BilanganPrima(){
        Scanner input;
        input = new Scanner(System.in);
        System.out.print("Masukkan Angka : ");
        int angka = input.nextInt();


        int i;
        int m=0;
        int cek=0;
        m = angka/2;

        if( angka == 0 || angka == 1){
            System.out.println(angka +" bukan bilangan prima");

        }else{
            for(i = 2; i <= m; i++){
                if(angka % i ==0){
                    System.out.println(angka +" bukan bilangan prima");
                    cek = 1;
                    break;
                }
            }if(cek == 0){
                System.out.println(angka +" adalah bilangan prima"); }
        }
    }


    public static void main(String[] args) {
        bio();
        BilanganPrima();
    }
}
